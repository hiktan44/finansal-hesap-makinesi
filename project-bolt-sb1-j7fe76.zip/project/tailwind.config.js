/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'navy': {
          800: '#1e3a8a',
          600: '#1e40af',
        },
        'yellow': {
          50: '#fefce8',
          100: '#fef9c3',
          200: '#fef08a',
          300: '#fde047',
          400: '#facc15',
          500: '#eab308',
          600: '#ca8a04'
        },
        'red': {
          500: '#ef4444',
          600: '#dc2626',
          700: '#b91c1c'
        }
      },
    },
  },
  plugins: [],
};