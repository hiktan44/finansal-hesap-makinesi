const webpack = require('@nativescript/webpack');
const { resolve } = require('path');

module.exports = (env) => {
  webpack.init(env);

  webpack.chainWebpack((config) => {
    // Web uygulaması build klasörünü kopyala
    config.plugin('CopyWebpackPlugin').tap((args) => {
      args[0].patterns.push({
        from: resolve(__dirname, 'dist'),
        to: 'dist',
        globOptions: {
          ignore: ['**/node_modules/**']
        }
      });
      return args;
    });

    // Optimize chunk loading
    config.optimization.splitChunks({
      chunks: 'all',
      minSize: 20000,
      maxSize: 500000,
      cacheGroups: {
        vendors: {
          test: /[\\/]node_modules[\\/]/,
          priority: -10
        },
        default: {
          minChunks: 2,
          priority: -20,
          reuseExistingChunk: true
        }
      }
    });
  });

  return webpack.resolveConfig();
};