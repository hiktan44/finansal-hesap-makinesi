import { Application } from '@nativescript/core';
import { WebViewPage } from './pages/webview-page';

Application.run({
    create: () => {
        const page = new WebViewPage();
        return page;
    },
});

Application.setCssFileName("app.css");