import { Page, WebView } from '@nativescript/core';

export class WebViewPage extends Page {
    constructor() {
        super();
        this.createUI();
    }

    private createUI() {
        const webView = new WebView();
        webView.src = 'http://localhost:4173';  // Vite preview server URL
        
        // Set full screen
        webView.height = { unit: '%', value: 100 };
        webView.width = { unit: '%', value: 100 };

        // Handle events
        webView.on('loadStarted', () => {
            console.log('Loading started');
        });

        webView.on('loadFinished', () => {
            console.log('Loading finished');
        });

        this.content = webView;
    }
}