import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

// iOS'ta dokunma gecikmesini kaldır
document.addEventListener('touchstart', function() {}, {passive: true});

// PWA servis işçisi kaydı - sadece production ortamında
if (import.meta.env.PROD && 'serviceWorker' in navigator && !import.meta.env.DEV) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(error => {
      console.error('SW kayıt hatası:', error);
    });
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);