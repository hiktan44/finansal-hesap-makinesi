import { createApp } from './ios/app/AppDelegate';
createApp();