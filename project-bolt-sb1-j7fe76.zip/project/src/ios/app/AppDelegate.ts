import { Application, Frame } from '@nativescript/core';
import { WebViewContainer } from '../webview/WebViewContainer';
import { NavigationService } from '../navigation/NavigationService';

export function createApp() {
    const frame = new Frame();
    NavigationService.initialize(frame);

    Application.run({
        create: () => {
            const page = new WebViewContainer();
            frame.navigate({
                create: () => page
            });
            return frame;
        }
    });
}