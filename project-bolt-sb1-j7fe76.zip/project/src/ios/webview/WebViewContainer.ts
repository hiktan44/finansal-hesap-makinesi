import { WebView, Page, EventData } from '@nativescript/core';

export class WebViewContainer extends Page {
    private webView: WebView;

    constructor() {
        super();
        this.createWebView();
        this.setupEventHandlers();
    }

    private createWebView() {
        this.webView = new WebView();
        this.webView.src = 'dist/index.html';
        this.webView.height = { unit: '%', value: 100 };
        this.webView.width = { unit: '%', value: 100 };
        this.content = this.webView;
    }

    private setupEventHandlers() {
        this.webView.on('loadStarted', (args: EventData) => {
            console.log('Page load started');
        });

        this.webView.on('loadFinished', (args: EventData) => {
            console.log('Page load completed');
        });
    }
}