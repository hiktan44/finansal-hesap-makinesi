import { Frame } from '@nativescript/core';

export class NavigationService {
    private static frame: Frame;

    static initialize(frame: Frame) {
        this.frame = frame;
    }

    static navigate(pageModulePath: string) {
        this.frame.navigate({
            moduleName: pageModulePath,
            animated: true
        });
    }

    static goBack() {
        if (this.frame.canGoBack()) {
            this.frame.goBack();
        }
    }
}