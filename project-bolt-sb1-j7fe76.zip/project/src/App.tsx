import React, { useState } from 'react';
import { Calculator, FileText, Home, Wallet, ArrowLeftRight } from 'lucide-react';
import { StandardCalculator } from './components/calculators/StandardCalculator';
import { MortgageCalculator } from './components/calculators/MortgageCalculator';
import { SavingsCalculator } from './components/calculators/SavingsCalculator';
import { CheckCalculator } from './components/calculators/CheckCalculator';
import { UnitConverter } from './components/converters/UnitConverter';
import { calculateExpression } from './utils/calculator';
import { Header } from './components/layout/Header';
import { Navigation } from './components/layout/Navigation';

type CalcType = 'standard' | 'mortgage' | 'savings' | 'check' | 'converter';

function App() {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [currentTime, setCurrentTime] = useState('');
  const [calcType, setCalcType] = useState<CalcType>('standard');
  
  // Financial calculators state
  const [loanAmount, setLoanAmount] = useState(100000);
  const [interestRate, setInterestRate] = useState(3.5);
  const [years, setYears] = useState(30);
  const [monthlyDeposit, setMonthlyDeposit] = useState(1000);

  React.useEffect(() => {
    const timer = setInterval(() => {
      const time = new Date().toLocaleTimeString('tr-TR');
      setCurrentTime(time);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleNumber = (num: string) => {
    if (display === '0' && num !== '.') {
      setDisplay(num);
      setEquation(equation === '0' ? num : equation + num);
    } else {
      setDisplay(display + num);
      setEquation(equation + num);
    }
  };

  const handleOperator = (op: string) => {
    setDisplay('0');
    setEquation(equation + ' ' + op + ' ');
  };

  const calculate = () => {
    try {
      const result = calculateExpression(equation);
      setDisplay(result);
      setEquation(result);
    } catch (error) {
      setDisplay('Hata');
      setEquation('');
    }
  };

  const clear = () => {
    setDisplay('0');
    setEquation('');
  };

  const renderCalculator = () => {
    switch (calcType) {
      case 'standard':
        return (
          <StandardCalculator
            display={display}
            equation={equation}
            handleNumber={handleNumber}
            handleOperator={handleOperator}
            calculate={calculate}
            clear={clear}
          />
        );
      case 'mortgage':
        return (
          <MortgageCalculator
            loanAmount={loanAmount}
            interestRate={interestRate}
            years={years}
            setLoanAmount={setLoanAmount}
            setInterestRate={setInterestRate}
            setYears={setYears}
          />
        );
      case 'savings':
        return (
          <SavingsCalculator
            monthlyDeposit={monthlyDeposit}
            interestRate={interestRate}
            years={years}
            setMonthlyDeposit={setMonthlyDeposit}
            setInterestRate={setInterestRate}
            setYears={setYears}
          />
        );
      case 'check':
        return <CheckCalculator />;
      case 'converter':
        return <UnitConverter />;
      default:
        return null;
    }
  };

  const calculatorTypes = [
    { id: 'standard', label: 'Hesap', icon: Calculator },
    { id: 'mortgage', label: 'Kredi', icon: Home },
    { id: 'savings', label: 'Birikim', icon: Wallet },
    { id: 'check', label: 'Çek', icon: FileText },
    { id: 'converter', label: 'Dönüştür', icon: ArrowLeftRight }
  ] as const;

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-100 to-orange-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-yellow-200 rounded-2xl shadow-2xl p-6 relative">
        <Header currentTime={currentTime} />
        <Navigation 
          calculatorTypes={calculatorTypes} 
          currentType={calcType} 
          onTypeChange={setCalcType} 
        />
        {renderCalculator()}
      </div>
    </div>
  );
}

export default App;