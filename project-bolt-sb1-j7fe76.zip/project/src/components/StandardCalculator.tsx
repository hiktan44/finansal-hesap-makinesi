import React from 'react';

interface StandardCalculatorProps {
  display: string;
  equation: string;
  handleNumber: (num: string) => void;
  handleOperator: (op: string) => void;
  calculate: () => void;
  clear: () => void;
}

export function StandardCalculator({
  display,
  equation,
  handleNumber,
  handleOperator,
  calculate,
  clear
}: StandardCalculatorProps) {
  const handlePercent = () => {
    try {
      const currentValue = parseFloat(display);
      const percentValue = currentValue / 100;
      const newEquation = equation.slice(0, equation.lastIndexOf(display)) + percentValue;
      handleNumber(percentValue.toString());
    } catch (error) {
      clear();
    }
  };

  const buttons = [
    'C', '%', '÷', '×',
    '7', '8', '9', '-',
    '4', '5', '6', '+',
    '1', '2', '3', '=',
    '0', '.'
  ];

  const getButtonClass = (btn: string) => {
    if (btn === '=') {
      return 'bg-blue-900 text-yellow-100 hover:bg-blue-800 col-span-2';
    }
    if (['÷', '×', '-', '+'].includes(btn)) {
      return 'bg-yellow-300 text-navy-800 hover:bg-yellow-400';
    }
    if (['C', '%'].includes(btn)) {
      return 'bg-red-500 text-white hover:bg-red-600';
    }
    return 'bg-yellow-50 text-navy-800 hover:bg-yellow-100';
  };

  const handleClick = (btn: string) => {
    switch (btn) {
      case 'C':
        clear();
        break;
      case '%':
        handlePercent();
        break;
      case '=':
        calculate();
        break;
      case '÷':
        handleOperator('/');
        break;
      case '×':
        handleOperator('*');
        break;
      case '+':
      case '-':
        handleOperator(btn);
        break;
      default:
        handleNumber(btn);
    }
  };

  return (
    <>
      <div className="bg-yellow-50 p-4 rounded-lg mb-4 text-right">
        <div className="text-sm text-navy-600 opacity-75 min-h-[1.5rem]">
          {equation || '0'}
        </div>
        <div className="text-3xl font-bold text-navy-800">
          {display}
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {buttons.map((btn) => (
          <button
            key={btn}
            onClick={() => handleClick(btn)}
            className={`${getButtonClass(btn)} p-4 rounded-lg text-xl font-semibold transition-colors duration-200 ${
              btn === '=' ? 'col-span-2' : ''
            }`}
          >
            {btn}
          </button>
        ))}
      </div>
    </>
  );
}