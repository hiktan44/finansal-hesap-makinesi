import React from 'react';

interface MortgageCalculatorProps {
  loanAmount: number;
  interestRate: number;
  years: number;
  setLoanAmount: (value: number) => void;
  setInterestRate: (value: number) => void;
  setYears: (value: number) => void;
}

export function MortgageCalculator({
  loanAmount,
  interestRate,
  years,
  setLoanAmount,
  setInterestRate,
  setYears
}: MortgageCalculatorProps) {
  const calculateMortgage = () => {
    const monthlyRate = interestRate / 1200;
    const months = years * 12;
    const monthlyPayment = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
    const totalPayment = monthlyPayment * months;
    const totalInterest = totalPayment - loanAmount;
    
    return {
      monthlyPayment: monthlyPayment.toFixed(2),
      totalPayment: totalPayment.toFixed(2),
      totalInterest: totalInterest.toFixed(2)
    };
  };

  const result = calculateMortgage();

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Kredi Tutarı (₺)</label>
          <input
            type="number"
            value={loanAmount}
            onChange={(e) => setLoanAmount(Number(e.target.value))}
            className="w-full p-2 border rounded-lg"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Faiz Oranı (%)</label>
          <input
            type="number"
            value={interestRate}
            onChange={(e) => setInterestRate(Number(e.target.value))}
            className="w-full p-2 border rounded-lg"
            step="0.1"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Vade (Yıl)</label>
          <input
            type="number"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
            className="w-full p-2 border rounded-lg"
          />
        </div>
      </div>

      <div className="bg-white rounded-lg p-4 shadow-inner">
        <table className="w-full">
          <tbody>
            <tr className="border-b">
              <td className="py-2 text-navy-800">Aylık Ödeme:</td>
              <td className="py-2 text-right font-bold">₺{result.monthlyPayment}</td>
            </tr>
            <tr className="border-b">
              <td className="py-2 text-navy-800">Toplam Ödeme:</td>
              <td className="py-2 text-right font-bold">₺{result.totalPayment}</td>
            </tr>
            <tr>
              <td className="py-2 text-navy-800">Toplam Faiz:</td>
              <td className="py-2 text-right font-bold">₺{result.totalInterest}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}