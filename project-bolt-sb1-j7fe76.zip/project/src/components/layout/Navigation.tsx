import React from 'react';
import { LucideIcon } from 'lucide-react';

interface NavigationProps {
  calculatorTypes: readonly {
    id: string;
    label: string;
    icon: LucideIcon;
  }[];
  currentType: string;
  onTypeChange: (type: any) => void;
}

export function Navigation({ calculatorTypes, currentType, onTypeChange }: NavigationProps) {
  return (
    <div className="grid grid-cols-5 gap-2 mb-6">
      {calculatorTypes.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onTypeChange(id)}
          className={`flex flex-col items-center justify-center gap-1 p-2 rounded-lg ${
            currentType === id ? 'bg-blue-900 text-white' : 'bg-yellow-300 text-navy-800'
          }`}
        >
          <Icon className="w-4 h-4" />
          <span className="text-xs">{label}</span>
        </button>
      ))}
    </div>
  );
}