import React from 'react';
import { Calculator } from 'lucide-react';

interface HeaderProps {
  currentTime: string;
}

export function Header({ currentTime }: HeaderProps) {
  return (
    <>
      <div className="absolute top-4 right-4 text-navy-800 font-bold">
        {currentTime}
      </div>
      
      <div className="flex items-center gap-2 mb-6">
        <Calculator className="w-6 h-6 text-navy-800" />
        <h1 className="text-2xl font-bold text-navy-800">Finansal Hesaplayıcı</h1>
      </div>
    </>
  );
}