import React, { useState } from 'react';
import { ArrowDownUp, Ruler, Scale, Thermometer, Clock, DollarSign } from 'lucide-react';

type UnitType = 'length' | 'weight' | 'temperature' | 'time' | 'currency';

interface UnitOption {
  label: string;
  value: string;
  rate: number;
}

const units: Record<UnitType, UnitOption[]> = {
  length: [
    { label: 'Meters', value: 'm', rate: 1 },
    { label: 'Kilometers', value: 'km', rate: 0.001 },
    { label: 'Centimeters', value: 'cm', rate: 100 },
    { label: 'Millimeters', value: 'mm', rate: 1000 },
    { label: 'Miles', value: 'mi', rate: 0.000621371 },
    { label: 'Yards', value: 'yd', rate: 1.09361 },
    { label: 'Feet', value: 'ft', rate: 3.28084 },
    { label: 'Inches', value: 'in', rate: 39.3701 }
  ],
  weight: [
    { label: 'Kilograms', value: 'kg', rate: 1 },
    { label: 'Grams', value: 'g', rate: 1000 },
    { label: 'Milligrams', value: 'mg', rate: 1000000 },
    { label: 'Pounds', value: 'lb', rate: 2.20462 },
    { label: 'Ounces', value: 'oz', rate: 35.274 }
  ],
  temperature: [
    { label: 'Celsius', value: 'C', rate: 1 },
    { label: 'Fahrenheit', value: 'F', rate: 1.8 },
    { label: 'Kelvin', value: 'K', rate: 1 }
  ],
  time: [
    { label: 'Seconds', value: 's', rate: 1 },
    { label: 'Minutes', value: 'min', rate: 1/60 },
    { label: 'Hours', value: 'h', rate: 1/3600 },
    { label: 'Days', value: 'd', rate: 1/86400 }
  ],
  currency: [
    { label: 'Turkish Lira', value: 'TRY', rate: 1 },
    { label: 'US Dollar', value: 'USD', rate: 0.031 },
    { label: 'Euro', value: 'EUR', rate: 0.029 },
    { label: 'British Pound', value: 'GBP', rate: 0.025 }
  ]
};

const typeColors = {
  length: { bg: 'from-purple-500 to-indigo-600', light: 'from-purple-400 to-indigo-500', text: 'text-purple-100' },
  weight: { bg: 'from-green-500 to-emerald-600', light: 'from-green-400 to-emerald-500', text: 'text-green-100' },
  temperature: { bg: 'from-red-500 to-rose-600', light: 'from-red-400 to-rose-500', text: 'text-red-100' },
  time: { bg: 'from-blue-500 to-cyan-600', light: 'from-blue-400 to-cyan-500', text: 'text-blue-100' },
  currency: { bg: 'from-amber-500 to-yellow-600', light: 'from-amber-400 to-yellow-500', text: 'text-amber-100' }
};

export function UnitConverter() {
  const [unitType, setUnitType] = useState<UnitType>('length');
  const [fromUnit, setFromUnit] = useState(units[unitType][0].value);
  const [toUnit, setToUnit] = useState(units[unitType][1].value);
  const [value, setValue] = useState('1');
  
  const convert = (value: string, from: string, to: string): string => {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) return '';
    
    const fromOption = units[unitType].find(u => u.value === from);
    const toOption = units[unitType].find(u => u.value === to);
    
    if (!fromOption || !toOption) return '';
    
    if (unitType === 'temperature') {
      let celsius;
      if (from === 'C') celsius = numValue;
      else if (from === 'F') celsius = (numValue - 32) / 1.8;
      else celsius = numValue - 273.15;
      
      if (to === 'C') return celsius.toFixed(2);
      else if (to === 'F') return (celsius * 1.8 + 32).toFixed(2);
      else return (celsius + 273.15).toFixed(2);
    }
    
    const result = numValue * (fromOption.rate / toOption.rate);
    return result.toFixed(4);
  };

  const getUnitIcon = () => {
    switch (unitType) {
      case 'length':
        return <Ruler className="w-8 h-8" />;
      case 'weight':
        return <Scale className="w-8 h-8" />;
      case 'temperature':
        return <Thermometer className="w-8 h-8" />;
      case 'time':
        return <Clock className="w-8 h-8" />;
      case 'currency':
        return <DollarSign className="w-8 h-8" />;
      default:
        return null;
    }
  };

  const handleSwap = () => {
    const tempUnit = fromUnit;
    setFromUnit(toUnit);
    setToUnit(tempUnit);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 p-4 flex items-center justify-center">
      <div className={`w-full max-w-md bg-gradient-to-br ${typeColors[unitType].bg} rounded-2xl shadow-2xl p-6 space-y-6`}>
        <div className="flex items-center gap-4 mb-6">
          <div className={`p-3 bg-white/10 rounded-xl ${typeColors[unitType].text}`}>
            {getUnitIcon()}
          </div>
          <h1 className="text-2xl font-bold text-white">Birim Dönüştürücü</h1>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-6">
          {Object.keys(units).map((type) => (
            <button
              key={type}
              onClick={() => {
                setUnitType(type as UnitType);
                setFromUnit(units[type as UnitType][0].value);
                setToUnit(units[type as UnitType][1].value);
                setValue('1');
              }}
              className={`p-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                unitType === type
                  ? 'bg-white text-gray-900 shadow-lg scale-105'
                  : 'bg-white/10 text-white/90 hover:bg-white/20'
              }`}
            >
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-white/90">Kaynak Birim</label>
            <select
              value={fromUnit}
              onChange={(e) => setFromUnit(e.target.value)}
              className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-white/50"
            >
              {units[unitType].map((unit) => (
                <option key={unit.value} value={unit.value} className="text-gray-900">
                  {unit.label}
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-center">
            <button
              onClick={handleSwap}
              className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            >
              <ArrowDownUp className="w-6 h-6 text-white" />
            </button>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-white/90">Hedef Birim</label>
            <select
              value={toUnit}
              onChange={(e) => setToUnit(e.target.value)}
              className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-white/50"
            >
              {units[unitType].map((unit) => (
                <option key={unit.value} value={unit.value} className="text-gray-900">
                  {unit.label}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-white/90">Değer</label>
            <input
              type="number"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-white/50"
              placeholder="Değer girin"
            />
          </div>

          <div className={`bg-gradient-to-br ${typeColors[unitType].light} p-6 rounded-xl shadow-lg`}>
            <div className="text-sm text-white/90">Sonuç:</div>
            <div className="text-3xl font-bold text-white mt-1">
              {convert(value, fromUnit, toUnit)} {toUnit}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}