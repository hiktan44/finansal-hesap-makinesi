import React, { useState } from 'react';

export function SavingsCalculator() {
  const [monthlyDeposit, setMonthlyDeposit] = useState(1000);
  const [interestRate, setInterestRate] = useState(15);
  const [years, setYears] = useState(10);

  const calculateSavings = () => {
    const monthlyRate = interestRate / 1200;
    const months = years * 12;
    const futureValue = monthlyDeposit * (Math.pow(1 + monthlyRate, months) - 1) / monthlyRate;
    const totalDeposits = monthlyDeposit * months;
    const interestEarned = futureValue - totalDeposits;
    
    return {
      futureValue: futureValue.toLocaleString('tr-TR', { maximumFractionDigits: 2 }),
      totalDeposits: totalDeposits.toLocaleString('tr-TR', { maximumFractionDigits: 2 }),
      interestEarned: interestEarned.toLocaleString('tr-TR', { maximumFractionDigits: 2 })
    };
  };

  const result = calculateSavings();

  return (
    <div className="max-w-md mx-auto space-y-6 text-navy-800">
      <div className="grid grid-cols-1 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Aylık Birikim (₺)</label>
          <input
            type="number"
            value={monthlyDeposit}
            onChange={(e) => setMonthlyDeposit(Number(e.target.value))}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Faiz Oranı (%)</label>
          <input
            type="number"
            value={interestRate}
            onChange={(e) => setInterestRate(Number(e.target.value))}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
            step="0.1"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Süre (Yıl)</label>
          <input
            type="number"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          />
        </div>
      </div>

      <div className="bg-yellow-100 rounded-xl p-6 space-y-4">
        <div className="flex justify-between items-center border-b border-yellow-200 pb-3">
          <span>Toplam Birikim:</span>
          <span className="font-bold">₺{result.futureValue}</span>
        </div>
        <div className="flex justify-between items-center border-b border-yellow-200 pb-3">
          <span>Yatırılan Para:</span>
          <span className="font-bold">₺{result.totalDeposits}</span>
        </div>
        <div className="flex justify-between items-center">
          <span>Kazanılan Faiz:</span>
          <span className="font-bold">₺{result.interestEarned}</span>
        </div>
      </div>
    </div>
  );
}