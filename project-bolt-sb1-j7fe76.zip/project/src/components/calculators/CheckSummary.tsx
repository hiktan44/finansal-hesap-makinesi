import React from 'react';

interface Check {
  amount: number;
  daysToMaturity: number;
  dueDate: string;
}

interface CheckSummaryProps {
  checks: Check[];
  formatCurrency: (value: number) => string;
  formatDate: (date: Date) => string;
}

export function CheckSummary({ checks, formatCurrency, formatDate }: CheckSummaryProps) {
  const calculateWeightedAverage = () => {
    const totalAmount = checks.reduce((sum, check) => sum + check.amount, 0);
    const weightedDays = checks.reduce((sum, check) => 
      sum + (check.amount * check.daysToMaturity), 0);
    
    const averageDays = totalAmount > 0 ? weightedDays / totalAmount : 0;
    const averageDate = new Date();
    averageDate.setDate(averageDate.getDate() + Math.round(averageDays));
    
    return {
      averageDays: averageDays.toFixed(1),
      averageDate,
      totalAmount,
      checkCount: checks.length
    };
  };

  const result = calculateWeightedAverage();

  return (
    <div className="bg-white rounded-lg p-6 shadow-inner space-y-6">
      <h2 className="text-xl font-bold text-navy-800 mb-4">Çek Portföy Özeti</h2>
      
      <table className="w-full">
        <tbody>
          <tr className="border-b">
            <td className="py-3 text-navy-800">Toplam Portföy:</td>
            <td className="py-3 text-right font-bold">₺ {formatCurrency(result.totalAmount)}</td>
          </tr>
          <tr className="border-b">
            <td className="py-3 text-navy-800">Çek Adedi:</td>
            <td className="py-3 text-right font-bold">{result.checkCount} adet</td>
          </tr>
          <tr className="border-b">
            <td className="py-3 text-navy-800">Ortalama Vade:</td>
            <td className="py-3 text-right font-bold">{result.averageDays} gün</td>
          </tr>
          <tr className="border-b">
            <td className="py-3 text-navy-800">Ortalama Vade Tarihi:</td>
            <td className="py-3 text-right font-bold">{formatDate(result.averageDate)}</td>
          </tr>
        </tbody>
      </table>

      <div className="mt-6">
        <h3 className="text-lg font-semibold text-navy-800 mb-4">Çek Listesi</h3>
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="py-2 text-left text-navy-800">Sıra</th>
              <th className="py-2 text-left text-navy-800">Tutar</th>
              <th className="py-2 text-left text-navy-800">Vade Tarihi</th>
              <th className="py-2 text-left text-navy-800">Vadeye Kalan</th>
            </tr>
          </thead>
          <tbody>
            {checks.map((check, index) => (
              <tr key={index} className="border-b">
                <td className="py-2">{index + 1}</td>
                <td className="py-2">₺ {formatCurrency(check.amount)}</td>
                <td className="py-2">{new Date(check.dueDate).toLocaleDateString('tr-TR')}</td>
                <td className="py-2">{check.daysToMaturity} gün</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}