import React, { useState } from 'react';

export function MortgageCalculator() {
  const [loanAmount, setLoanAmount] = useState(100000);
  const [interestRate, setInterestRate] = useState(1.79);
  const [years, setYears] = useState(10);

  const calculateMortgage = () => {
    const monthlyRate = interestRate / 1200;
    const months = years * 12;
    const monthlyPayment = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
    const totalPayment = monthlyPayment * months;
    const totalInterest = totalPayment - loanAmount;
    
    return {
      monthlyPayment: monthlyPayment.toLocaleString('tr-TR', { maximumFractionDigits: 2 }),
      totalPayment: totalPayment.toLocaleString('tr-TR', { maximumFractionDigits: 2 }),
      totalInterest: totalInterest.toLocaleString('tr-TR', { maximumFractionDigits: 2 })
    };
  };

  const result = calculateMortgage();

  return (
    <div className="max-w-md mx-auto space-y-6">
      <div className="grid grid-cols-1 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Kredi Tutarı (₺)</label>
          <input
            type="number"
            value={loanAmount}
            onChange={(e) => setLoanAmount(Number(e.target.value))}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Faiz Oranı (%)</label>
          <input
            type="number"
            value={interestRate}
            onChange={(e) => setInterestRate(Number(e.target.value))}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
            step="0.01"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Vade (Yıl)</label>
          <input
            type="number"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          />
        </div>
      </div>

      <div className="bg-yellow-100 rounded-xl p-6 space-y-4">
        <div className="flex justify-between items-center border-b border-yellow-200 pb-3">
          <span className="text-navy-800">Aylık Taksit:</span>
          <span className="font-bold text-navy-800">₺{result.monthlyPayment}</span>
        </div>
        <div className="flex justify-between items-center border-b border-yellow-200 pb-3">
          <span className="text-navy-800">Toplam Ödeme:</span>
          <span className="font-bold text-navy-800">₺{result.totalPayment}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-navy-800">Toplam Faiz:</span>
          <span className="font-bold text-navy-800">₺{result.totalInterest}</span>
        </div>
      </div>
    </div>
  );
}