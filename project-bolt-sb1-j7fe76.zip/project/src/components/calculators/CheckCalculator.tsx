import React, { useState, useRef } from 'react';
import { Plus, Trash2, FileDown } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { CheckSummary } from './CheckSummary';

interface Check {
  amount: number;
  daysToMaturity: number;
  dueDate: string;
}

const MAX_CHECKS = 50;

export function CheckCalculator() {
  const [checks, setChecks] = useState<Check[]>([
    { amount: 1000, daysToMaturity: 30, dueDate: new Date().toISOString().split('T')[0] },
  ]);
  
  const summaryRef = useRef<HTMLDivElement>(null);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('tr-TR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const calculateDaysToMaturity = (dueDate: string) => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const addCheck = () => {
    if (checks.length < MAX_CHECKS) {
      const newCheck = { 
        amount: 0, 
        daysToMaturity: 0, 
        dueDate: new Date().toISOString().split('T')[0] 
      };
      setChecks([newCheck, ...checks]);
    }
  };

  const removeCheck = (index: number) => {
    setChecks(checks.filter((_, i) => i !== index));
  };

  const updateCheck = (index: number, field: keyof Check, value: any) => {
    const newChecks = [...checks];
    if (field === 'dueDate') {
      newChecks[index] = { 
        ...newChecks[index], 
        dueDate: value,
        daysToMaturity: calculateDaysToMaturity(value)
      };
    } else {
      newChecks[index] = { ...newChecks[index], [field]: value };
    }
    setChecks(newChecks);
  };

  const exportToPDF = async () => {
    if (summaryRef.current) {
      const canvas = await html2canvas(summaryRef.current);
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`çek-portföy-özeti-${new Date().toLocaleDateString('tr-TR')}.pdf`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex gap-4">
          <button
            onClick={addCheck}
            disabled={checks.length >= MAX_CHECKS}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
              checks.length >= MAX_CHECKS
                ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
                : 'bg-yellow-300 text-navy-800 hover:bg-yellow-400'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>Çek Ekle</span>
          </button>
          <button
            onClick={exportToPDF}
            className="flex items-center gap-2 px-4 py-2 bg-blue-900 text-white rounded-lg hover:bg-blue-800 transition-colors"
          >
            <FileDown className="w-4 h-4" />
            <span>PDF İndir</span>
          </button>
        </div>
        <span className="text-sm text-navy-600">
          {checks.length} / {MAX_CHECKS} çek
        </span>
      </div>

      <div className="max-h-[400px] overflow-y-auto space-y-4 pr-2">
        {checks.map((check, index) => (
          <div key={index} className="bg-yellow-50 p-4 rounded-lg space-y-4">
            <div className="flex gap-4 items-end">
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium text-navy-800">Çek Tutarı</label>
                <div className="relative">
                  <input
                    type="text"
                    value={check.amount > 0 ? formatCurrency(check.amount) : ''}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      updateCheck(index, 'amount', Number(value));
                    }}
                    placeholder="0"
                    className="w-full p-2 pl-8 border rounded-lg"
                  />
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">₺</span>
                </div>
              </div>
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium text-navy-800">Vade Tarihi</label>
                <input
                  type="date"
                  value={check.dueDate}
                  onChange={(e) => updateCheck(index, 'dueDate', e.target.value)}
                  className="w-full p-2 border rounded-lg"
                />
              </div>
              <button
                onClick={() => removeCheck(index)}
                className="mb-2 p-2 text-red-500 hover:text-red-700 transition-colors"
                disabled={checks.length === 1}
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
            <div className="text-sm text-navy-600">
              Vadeye Kalan: <span className="font-semibold">{check.daysToMaturity} gün</span>
            </div>
          </div>
        ))}
      </div>

      <div ref={summaryRef}>
        <CheckSummary
          checks={checks}
          formatCurrency={formatCurrency}
          formatDate={formatDate}
        />
      </div>
    </div>
  );
}