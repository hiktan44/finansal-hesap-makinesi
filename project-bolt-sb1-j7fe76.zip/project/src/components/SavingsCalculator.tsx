import React from 'react';

interface SavingsCalculatorProps {
  monthlyDeposit: number;
  interestRate: number;
  years: number;
  setMonthlyDeposit: (value: number) => void;
  setInterestRate: (value: number) => void;
  setYears: (value: number) => void;
}

export function SavingsCalculator({
  monthlyDeposit,
  interestRate,
  years,
  setMonthlyDeposit,
  setInterestRate,
  setYears
}: SavingsCalculatorProps) {
  const calculateSavings = () => {
    const monthlyRate = interestRate / 1200;
    const months = years * 12;
    const futureValue = monthlyDeposit * (Math.pow(1 + monthlyRate, months) - 1) / monthlyRate;
    const totalDeposits = monthlyDeposit * months;
    const interestEarned = futureValue - totalDeposits;
    
    return {
      futureValue: futureValue.toFixed(2),
      totalDeposits: totalDeposits.toFixed(2),
      interestEarned: interestEarned.toFixed(2)
    };
  };

  const result = calculateSavings();

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Aylık Birikim (₺)</label>
          <input
            type="number"
            value={monthlyDeposit}
            onChange={(e) => setMonthlyDeposit(Number(e.target.value))}
            className="w-full p-2 border rounded-lg"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Faiz Oranı (%)</label>
          <input
            type="number"
            value={interestRate}
            onChange={(e) => setInterestRate(Number(e.target.value))}
            className="w-full p-2 border rounded-lg"
            step="0.1"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Süre (Yıl)</label>
          <input
            type="number"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
            className="w-full p-2 border rounded-lg"
          />
        </div>
      </div>

      <div className="bg-white rounded-lg p-4 shadow-inner">
        <table className="w-full">
          <tbody>
            <tr className="border-b">
              <td className="py-2 text-navy-800">Gelecek Değer:</td>
              <td className="py-2 text-right font-bold">₺{result.futureValue}</td>
            </tr>
            <tr className="border-b">
              <td className="py-2 text-navy-800">Toplam Yatırım:</td>
              <td className="py-2 text-right font-bold">₺{result.totalDeposits}</td>
            </tr>
            <tr>
              <td className="py-2 text-navy-800">Kazanılan Faiz:</td>
              <td className="py-2 text-right font-bold">₺{result.interestEarned}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}