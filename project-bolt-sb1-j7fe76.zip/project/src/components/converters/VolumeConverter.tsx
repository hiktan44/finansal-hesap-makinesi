import React, { useState, useEffect } from 'react';

const units = {
  m3: { label: 'Metreküp', toBase: (v: number) => v * 1000 },
  l: { label: 'Litre', toBase: (v: number) => v },
  ml: { label: 'Mililitre', toBase: (v: number) => v / 1000 },
  gal: { label: 'Galon', toBase: (v: number) => v * 3.78541 },
  qt: { label: 'Quart', toBase: (v: number) => v * 0.946353 },
  pt: { label: 'Pint', toBase: (v: number) => v * 0.473176 },
  cup: { label: 'Cup', toBase: (v: number) => v * 0.236588 },
  fl_oz: { label: 'Fluid Ounce', toBase: (v: number) => v * 0.0295735 }
};

export function VolumeConverter() {
  const [fromValue, setFromValue] = useState<string>('1');
  const [fromUnit, setFromUnit] = useState<keyof typeof units>('l');
  const [toUnit, setToUnit] = useState<keyof typeof units>('ml');
  const [result, setResult] = useState<string>('1000');

  useEffect(() => {
    const calculate = () => {
      const value = parseFloat(fromValue);
      if (isNaN(value)) {
        setResult('');
        return;
      }

      const baseValue = units[fromUnit].toBase(value);
      const resultValue = baseValue / units[toUnit].toBase(1);
      setResult(resultValue.toLocaleString('tr-TR', { maximumFractionDigits: 6 }));
    };

    calculate();
  }, [fromValue, fromUnit, toUnit]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Değer</label>
          <input
            type="number"
            value={fromValue}
            onChange={(e) => setFromValue(e.target.value)}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
            placeholder="0"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Birim</label>
          <select
            value={fromUnit}
            onChange={(e) => setFromUnit(e.target.value as keyof typeof units)}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Sonuç</label>
          <input
            type="text"
            value={result}
            readOnly
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Birim</label>
          <select
            value={toUnit}
            onChange={(e) => setToUnit(e.target.value as keyof typeof units)}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}