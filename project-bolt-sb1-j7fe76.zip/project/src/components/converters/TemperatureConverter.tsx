import React, { useState, useEffect } from 'react';

const units = {
  celsius: { label: 'Celsius', convert: (val: number, to: string) => {
    if (to === 'fahrenheit') return (val * 9/5) + 32;
    if (to === 'kelvin') return val + 273.15;
    return val;
  }},
  fahrenheit: { label: 'Fahrenheit', convert: (val: number, to: string) => {
    if (to === 'celsius') return (val - 32) * 5/9;
    if (to === 'kelvin') return (val - 32) * 5/9 + 273.15;
    return val;
  }},
  kelvin: { label: 'Kelvin', convert: (val: number, to: string) => {
    if (to === 'celsius') return val - 273.15;
    if (to === 'fahrenheit') return (val - 273.15) * 9/5 + 32;
    return val;
  }}
};

export function TemperatureConverter() {
  const [fromUnit, setFromUnit] = useState('celsius');
  const [toUnit, setToUnit] = useState('fahrenheit');
  const [fromValue, setFromValue] = useState('0');
  const [toValue, setToValue] = useState('');

  useEffect(() => {
    const from = parseFloat(fromValue) || 0;
    const result = units[fromUnit].convert(from, toUnit);
    setToValue(result.toFixed(2));
  }, [fromValue, fromUnit, toUnit]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Kaynak Birim</label>
          <select
            value={fromUnit}
            onChange={(e) => setFromUnit(e.target.value)}
            className="w-full p-2 border rounded-lg"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
          <input
            type="number"
            value={fromValue}
            onChange={(e) => setFromValue(e.target.value)}
            className="w-full p-2 border rounded-lg"
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Hedef Birim</label>
          <select
            value={toUnit}
            onChange={(e) => setToUnit(e.target.value)}
            className="w-full p-2 border rounded-lg"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
          <input
            type="text"
            value={toValue}
            readOnly
            className="w-full p-2 border rounded-lg bg-gray-50"
          />
        </div>
      </div>
    </div>
  );
}