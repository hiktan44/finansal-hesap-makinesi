import React, { useState } from 'react';
import { Ruler, Scale, Thermometer, Gauge, Move, Clock, DollarSign } from 'lucide-react';
import { LengthConverter } from './LengthConverter';
import { WeightConverter } from './WeightConverter';
import { TemperatureConverter } from './TemperatureConverter';
import { SpeedConverter } from './SpeedConverter';
import { AreaConverter } from './AreaConverter';
import { TimeConverter } from './TimeConverter';
import { CurrencyConverter } from './CurrencyConverter';

type ConverterType = 'length' | 'weight' | 'temperature' | 'speed' | 'area' | 'time' | 'currency';

const converters = [
  { id: 'length', label: 'Uzunluk', icon: Ruler },
  { id: 'weight', label: 'Ağırlık', icon: Scale },
  { id: 'temperature', label: 'Sıcaklık', icon: Thermometer },
  { id: 'speed', label: 'Hız', icon: Gauge },
  { id: 'area', label: 'Alan', icon: Move },
  { id: 'time', label: 'Zaman', icon: Clock },
  { id: 'currency', label: 'Para', icon: DollarSign }
];

export function UnitConverter() {
  const [activeConverter, setActiveConverter] = useState<ConverterType>('length');

  const renderConverter = () => {
    switch (activeConverter) {
      case 'length':
        return <LengthConverter />;
      case 'weight':
        return <WeightConverter />;
      case 'temperature':
        return <TemperatureConverter />;
      case 'speed':
        return <SpeedConverter />;
      case 'area':
        return <AreaConverter />;
      case 'time':
        return <TimeConverter />;
      case 'currency':
        return <CurrencyConverter />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-7 gap-2">
        {converters.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveConverter(id as ConverterType)}
            className={`flex flex-col items-center justify-center gap-2 p-3 rounded-lg transition-colors ${
              activeConverter === id
                ? 'bg-blue-900 text-white'
                : 'bg-yellow-300 text-navy-800 hover:bg-yellow-400'
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-sm font-medium">{label}</span>
          </button>
        ))}
      </div>

      <div className="bg-white rounded-lg p-6 shadow-inner">
        {renderConverter()}
      </div>
    </div>
  );
}