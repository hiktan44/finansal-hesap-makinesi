import React, { useState, useEffect } from 'react';

const units = {
  yr: { label: 'Yıl', toBase: (v: number) => v * 31536000 },
  month: { label: 'Ay', toBase: (v: number) => v * 2592000 },
  week: { label: 'Hafta', toBase: (v: number) => v * 604800 },
  day: { label: 'Gün', toBase: (v: number) => v * 86400 },
  hr: { label: 'Saat', toBase: (v: number) => v * 3600 },
  min: { label: 'Dakika', toBase: (v: number) => v * 60 },
  sec: { label: 'Saniye', toBase: (v: number) => v }
};

export function TimeConverter() {
  const [fromValue, setFromValue] = useState<string>('1');
  const [fromUnit, setFromUnit] = useState<keyof typeof units>('hr');
  const [toUnit, setToUnit] = useState<keyof typeof units>('min');
  const [result, setResult] = useState<string>('60');

  useEffect(() => {
    const calculate = () => {
      const value = parseFloat(fromValue);
      if (isNaN(value)) {
        setResult('');
        return;
      }

      const baseValue = units[fromUnit].toBase(value);
      const resultValue = baseValue / units[toUnit].toBase(1);
      setResult(resultValue.toLocaleString('tr-TR', { maximumFractionDigits: 6 }));
    };

    calculate();
  }, [fromValue, fromUnit, toUnit]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Değer</label>
          <input
            type="number"
            value={fromValue}
            onChange={(e) => setFromValue(e.target.value)}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
            placeholder="0"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Birim</label>
          <select
            value={fromUnit}
            onChange={(e) => setFromUnit(e.target.value as keyof typeof units)}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Sonuç</label>
          <input
            type="text"
            value={result}
            readOnly
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Birim</label>
          <select
            value={toUnit}
            onChange={(e) => setToUnit(e.target.value as keyof typeof units)}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}