import React, { useState, useEffect, useCallback } from 'react';

interface ExchangeRates {
  [key: string]: number;
}

const defaultRates: ExchangeRates = {
  try: 1,
  usd: 31.95,
  eur: 34.65,
  gbp: 40.45,
  jpy: 0.21,
  chf: 35.85,
  aud: 20.85,
  cad: 23.55
};

const currencyLabels = {
  try: 'Türk Lirası',
  usd: 'Amerikan Doları',
  eur: 'Euro',
  gbp: 'İngiliz Sterlini',
  jpy: 'Japon Yeni',
  chf: 'İsviçre Frangı',
  aud: 'Avustralya Doları',
  cad: 'Kanada Doları'
};

const currencySymbols = {
  try: '₺',
  usd: '$',
  eur: '€',
  gbp: '£',
  jpy: '¥',
  chf: 'Fr',
  aud: 'A$',
  cad: 'C$'
};

const UPDATE_INTERVAL = 300000; // 5 minutes in milliseconds

export function CurrencyConverter() {
  const [fromValue, setFromValue] = useState<string>('1');
  const [fromUnit, setFromUnit] = useState<string>('usd');
  const [toUnit, setToUnit] = useState<string>('try');
  const [result, setResult] = useState<string>('31.95');
  const [rates, setRates] = useState<ExchangeRates>(defaultRates);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [nextUpdate, setNextUpdate] = useState<number>(UPDATE_INTERVAL);

  const fetchRates = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch('https://api.exchangerate-api.com/v4/latest/TRY');
      const data = await response.json();
      
      if (data.rates) {
        const newRates: ExchangeRates = {
          try: 1,
          usd: 1 / data.rates.USD,
          eur: 1 / data.rates.EUR,
          gbp: 1 / data.rates.GBP,
          jpy: 1 / data.rates.JPY,
          chf: 1 / data.rates.CHF,
          aud: 1 / data.rates.AUD,
          cad: 1 / data.rates.CAD
        };
        setRates(newRates);
        setLastUpdate(new Date());
      }
    } catch (err) {
      setError('Kurlar güncellenemedi, varsayılan değerler kullanılıyor');
      console.error('Failed to fetch rates:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRates();
    
    const interval = setInterval(() => {
      fetchRates();
    }, UPDATE_INTERVAL);

    return () => clearInterval(interval);
  }, [fetchRates]);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const diff = UPDATE_INTERVAL - (now.getTime() - lastUpdate.getTime());
      setNextUpdate(Math.max(0, diff));
    }, 1000);

    return () => clearInterval(timer);
  }, [lastUpdate]);

  useEffect(() => {
    const calculate = () => {
      const value = parseFloat(fromValue);
      if (isNaN(value)) {
        setResult('');
        return;
      }

      const fromRate = rates[fromUnit as keyof typeof rates];
      const toRate = rates[toUnit as keyof typeof rates];
      const resultValue = (value * fromRate) / toRate;
      
      setResult(resultValue.toLocaleString('tr-TR', { 
        maximumFractionDigits: 2,
        minimumFractionDigits: 2
      }));
    };

    calculate();
  }, [fromValue, fromUnit, toUnit, rates]);

  const formatTimeRemaining = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm">
          {error}
        </div>
      )}
      
      {loading && (
        <div className="bg-blue-50 text-blue-600 p-3 rounded-lg text-sm">
          Döviz kurları güncelleniyor...
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Değer</label>
          <div className="relative">
            <input
              type="number"
              value={fromValue}
              onChange={(e) => setFromValue(e.target.value)}
              className="w-full pl-8 p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
              placeholder="0"
            />
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">
              {currencySymbols[fromUnit as keyof typeof currencySymbols]}
            </span>
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Para Birimi</label>
          <select
            value={fromUnit}
            onChange={(e) => setFromUnit(e.target.value)}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          >
            {Object.entries(currencyLabels).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Sonuç</label>
          <div className="relative">
            <input
              type="text"
              value={result}
              readOnly
              className="w-full pl-8 p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
            />
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">
              {currencySymbols[toUnit as keyof typeof currencySymbols]}
            </span>
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-navy-800">Para Birimi</label>
          <select
            value={toUnit}
            onChange={(e) => setToUnit(e.target.value)}
            className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl text-navy-800 focus:outline-none focus:ring-2 focus:ring-yellow-300"
          >
            {Object.entries(currencyLabels).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex justify-between items-center text-xs text-gray-500">
        <div>
          Son güncelleme: {lastUpdate.toLocaleTimeString('tr-TR')}
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          Sonraki güncelleme: {formatTimeRemaining(nextUpdate)}
        </div>
      </div>

      <button
        onClick={fetchRates}
        className="w-full p-2 text-sm bg-blue-900 text-white rounded-lg hover:bg-blue-800 transition-colors"
      >
        Kurları Güncelle
      </button>
    </div>
  );
}