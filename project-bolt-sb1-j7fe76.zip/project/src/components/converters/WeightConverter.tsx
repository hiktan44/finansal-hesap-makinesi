import React, { useState, useEffect } from 'react';

const units = {
  kilogram: { label: 'Kilogram', factor: 1 },
  gram: { label: 'Gram', factor: 0.001 },
  milligram: { label: 'Miligram', factor: 0.000001 },
  pound: { label: 'Pound', factor: 0.453592 },
  ounce: { label: 'Ons', factor: 0.0283495 },
  ton: { label: 'Ton', factor: 1000 }
};

export function WeightConverter() {
  const [fromUnit, setFromUnit] = useState('kilogram');
  const [toUnit, setToUnit] = useState('gram');
  const [fromValue, setFromValue] = useState('1');
  const [toValue, setToValue] = useState('');

  useEffect(() => {
    const from = parseFloat(fromValue) || 0;
    const result = (from * units[fromUnit].factor) / units[toUnit].factor;
    setToValue(result.toFixed(6));
  }, [fromValue, fromUnit, toUnit]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Kaynak Birim</label>
          <select
            value={fromUnit}
            onChange={(e) => setFromUnit(e.target.value)}
            className="w-full p-2 border rounded-lg"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
          <input
            type="number"
            value={fromValue}
            onChange={(e) => setFromValue(e.target.value)}
            className="w-full p-2 border rounded-lg"
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Hedef Birim</label>
          <select
            value={toUnit}
            onChange={(e) => setToUnit(e.target.value)}
            className="w-full p-2 border rounded-lg"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
          <input
            type="text"
            value={toValue}
            readOnly
            className="w-full p-2 border rounded-lg bg-gray-50"
          />
        </div>
      </div>
    </div>
  );
}