import React, { useState, useEffect } from 'react';

const units = {
  metre: { label: 'Metre', factor: 1 },
  kilometre: { label: 'Kilometre', factor: 1000 },
  centimetre: { label: 'Santimetre', factor: 0.01 },
  millimetre: { label: 'Milimetre', factor: 0.001 },
  mile: { label: 'Mil', factor: 1609.34 },
  yard: { label: 'Yarda', factor: 0.9144 },
  foot: { label: 'Fit', factor: 0.3048 },
  inch: { label: 'İnç', factor: 0.0254 }
};

export function LengthConverter() {
  const [fromUnit, setFromUnit] = useState('metre');
  const [toUnit, setToUnit] = useState('kilometre');
  const [fromValue, setFromValue] = useState('1');
  const [toValue, setToValue] = useState('');

  useEffect(() => {
    const from = parseFloat(fromValue) || 0;
    const result = (from * units[fromUnit].factor) / units[toUnit].factor;
    setToValue(result.toFixed(6));
  }, [fromValue, fromUnit, toUnit]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Kaynak Birim</label>
          <select
            value={fromUnit}
            onChange={(e) => setFromUnit(e.target.value)}
            className="w-full p-2 border rounded-lg"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
          <input
            type="number"
            value={fromValue}
            onChange={(e) => setFromValue(e.target.value)}
            className="w-full p-2 border rounded-lg"
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Hedef Birim</label>
          <select
            value={toUnit}
            onChange={(e) => setToUnit(e.target.value)}
            className="w-full p-2 border rounded-lg"
          >
            {Object.entries(units).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
          <input
            type="text"
            value={toValue}
            readOnly
            className="w-full p-2 border rounded-lg bg-gray-50"
          />
        </div>
      </div>
    </div>
  );
}