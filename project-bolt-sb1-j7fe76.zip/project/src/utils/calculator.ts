export function calculateExpression(expression: string): string {
  try {
    // Remove any trailing operators
    const cleanExpression = expression.replace(/[+\-*/]\s*$/, '');
    
    // Replace multiple operators with the last one
    const normalizedExpression = cleanExpression.replace(/([+\-*/])\s*([+\-*/])+/g, '$2');
    
    // Evaluate the expression safely without using eval
    const result = Function('"use strict";return (' + normalizedExpression + ')')();
    
    // Format the result
    if (Number.isFinite(result)) {
      const formatted = Number(result.toFixed(8)).toString();
      return formatted.replace(/\.?0+$/, '');
    }
    
    throw new Error('Invalid calculation');
  } catch (error) {
    return 'Hata';
  }
}