import { AppRegistry } from 'react-native';
import App from './src/App.native';

AppRegistry.registerComponent('FinancialCalculator', () => App);