const { getDefaultConfig } = require('@react-native/metro-config');

module.exports = (async () => {
  const config = await getDefaultConfig(__dirname);
  
  return {
    ...config,
    transformer: {
      ...config.transformer,
      babelTransformerPath: require.resolve('react-native-web/babel')
    },
    resolver: {
      ...config.resolver,
      sourceExts: ['native.tsx', 'tsx', 'ts', 'js', 'jsx']
    }
  };
})();